from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils.translation import activate, get_language
from .models import Language
from .serializers import LanguageSerializer

class LanguageList(APIView):
    def get(self, request):
        # Retrieve available languages
        languages = Language.objects.all()
        serializer = LanguageSerializer(languages, many=True)
        return Response({
            'current_language': get_language(),  # Include active language in response
            'languages': serializer.data
        }, status=status.HTTP_200_OK)

    def post(self, request):
        # Switch language based on 'language_code' sent in the request
        language_code = request.data.get('language_code')

        # Validate language choice
        available_languages = [lang.code for lang in Language.objects.all()]
        if language_code not in available_languages:
            return Response(
                {"error": "Invalid language code."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Set the active language
        activate(language_code)

        return Response(
            {"message": f"Language changed to {language_code}"},
            status=status.HTTP_200_OK
        )

class SelectLanguage(APIView):
    def post(self, request):
        """ Allows the user to select a language and store the preference """
        language_code = request.data.get('language_code')

        # Validate language choice
        available_languages = [lang.code for lang in Language.objects.all()]
        if language_code not in available_languages:
            return Response(
                {"error": "Invalid language code."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Set the active language
        activate(language_code)

        # Store language preference in the session
        request.session['language_code'] = language_code

        return Response(
            {"message": f"Language set to {language_code}", "current_language": language_code},
            status=status.HTTP_200_OK
        )
