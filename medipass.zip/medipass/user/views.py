import qrcode
import io
import base64
from rest_framework.views import APIView
from django.views.decorators.csrf import  csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import update_last_login
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from .models import User
from .serializers import UserSerializer


class RegisterView(APIView):
    permission_classes = [AllowAny]  # Anyone can register

    def post(self, request):
        try:
            print("Incoming request data:", request.data)
            serializer = UserSerializer(data=request.data)
            if serializer.is_valid():
                user = serializer.save()
                user.set_password(request.data["password"])  # Hash password
                user.save()
                return Response({"message": "User registered successfully!"}, status=status.HTTP_201_CREATED)
            else:
                print("Serializer errors:", serializer.errors)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print("Exception:", str(e))
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
class LoginView(APIView):
    permission_classes = [AllowAny]  # Anyone can attempt to log in

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        user = authenticate(username=username, password=password)

        if user:
            # Session Login
            login(request, user)
            update_last_login(None, user)

            # Generate JWT Token
            refresh = RefreshToken.for_user(user)
            access_token = str(refresh.access_token)

            return Response({
                "message": "Login successful!",
                "access_token": access_token,
                "refresh_token": str(refresh),
            }, status=status.HTTP_200_OK)

        return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        # Logout from Django session
        logout(request)

        # Optionally, blacklist JWT token (requires `rest_framework_simplejwt.token_blacklist` setup)
        refresh_token = request.data.get("refresh_token")
        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()  # Blacklist token (requires settings configuration)
            except Exception as e:
                return Response({"error": "Invalid refresh token"}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"message": "Logged out successfully!"}, status=status.HTTP_200_OK)


class UserProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        serializer = UserSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)


class GenerateQRCodeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user  # Get the logged-in user
        user_data = {
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "date_of_birth": str(user.date_of_birth) if user.date_of_birth else "",
            "gender": user.gender,
            "national_id": user.national_id if user.national_id else "",
            "insurance_id": user.insurance_id if user.insurance_id else "",
            "insurance_provider": user.insurance_provider,
        }
        
        # Convert dictionary to string format
        user_data_str = "\n".join([f"{key}: {value}" for key, value in user_data.items()])
        
        # Generate QR Code
        qr = qrcode.make(user_data_str)
        
        # Save QR code to a BytesIO object
        buffer = io.BytesIO()
        qr.save(buffer, format="PNG")
        
        # Encode image to base64 to send as JSON response
        qr_base64 = base64.b64encode(buffer.getvalue()).decode()

        return Response({"qr_code": qr_base64}, status=status.HTTP_200_OK)
