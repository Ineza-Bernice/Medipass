from django.urls import path
from .views import LanguageList, SelectLanguage

urlpatterns = [
    path('languages/', LanguageList.as_view(), name='language-list'),  # Show available languages
    path('select/', SelectLanguage.as_view(), name='select-language'),  # User selects a language
]
