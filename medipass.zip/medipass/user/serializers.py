from django.contrib.auth import get_user_model
from rest_framework import serializers

# Import your custom user model
from .models import User  # Ensure this matches your model name

User = get_user_model()  # Dynamically get the User model

class RegisterSerializer(serializers.ModelSerializer):
    date_of_birth = serializers.DateField()
    gender = serializers.ChoiceField(choices=[('Male', 'Male'), ('Female', 'Female')])
    national_id = serializers.CharField(max_length=20, write_only=True)
    insurance_provider = serializers.CharField(max_length=100)
    insurance_id = serializers.CharField(max_length=50, write_only=True)
    valid_until = serializers.DateField()
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'date_of_birth', 'gender',
                  'national_id', 'insurance_provider', 'insurance_id', 'valid_until']
        extra_kwargs = {'password': {'write_only': True}}

    def validate_national_id(self, value):
        """Ensure the national ID is unique."""
        if User.objects.filter(national_id=value).exists():
            raise serializers.ValidationError("This national ID is already registered.")
        return value

    def create(self, validated_data):
        """Create a new user with hashed password."""
        password = validated_data.pop("password")

        user = User(**validated_data)
        user.set_password(password)  # Hash the password
        user.save()

        return user


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "first_name", "last_name", "email",
                  "date_of_birth", "gender", "national_id", "insurance_id", "insurance_provider"]
