from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):  
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[("Male", "Male"), ("Female", "Female")])
    national_id = models.CharField(max_length=20, unique=True)
    insurance_id = models.CharField(max_length=20, unique=True)
    insurance_provider = models.CharField(max_length=100)

    def __str__(self):
        return self.username
